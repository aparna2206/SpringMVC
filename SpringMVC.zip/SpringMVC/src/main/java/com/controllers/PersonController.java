package com.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.servlet.ModelAndView;

import org.springframework.web.servlet.ModelAndView;

import com.entities.Person;
import com.services.PersonService;

@Controller
public class PersonController {

	
	   @RequestMapping("/person")
	    public ModelAndView helloWorld() {

	        String message = "Hello World, Spring 3.0!";
	        return new ModelAndView("person", "message", message); 
	    }


	
	   private PersonService personService;
		
		@Autowired(required=true)
		@Qualifier(value="personService")
		public void setPersonService(PersonService ps){
			this.personService = ps;
		}
		
		@RequestMapping(value = "/persons", method = RequestMethod.GET)
		public String listPersons(Model model) {
			model.addAttribute("person", new Person());
			model.addAttribute("listPersons", this.personService.listPersons());
			return "person";
		}
	
		@RequestMapping(value = "/person",method = RequestMethod.GET)
	    public ModelAndView initView() {
			Person person = new Person();
			
	        return new ModelAndView("person", "person", person );
	    }
		
		@RequestMapping(value="/person/add", method = RequestMethod.POST)
		public String addPerson(@ModelAttribute("person") Person p){
		
			if(p.getId() == 0){
				//new person, add it
				this.personService.addPerson(p);
			}else{
				//existing person, call update
				this.personService.updatePerson(p);
			}
			
			return "redirect:/persons";
			
		}

		   @RequestMapping("/edit/{id}")
		    public String editPerson(@PathVariable("id") int id, Model model){
		        model.addAttribute("person", this.personService.getPersonById(id));
		        model.addAttribute("listPersons", this.personService.listPersons());
		        return "person";
		    }

			@RequestMapping("/remove/{id}")
		    public String removePerson(@PathVariable("id") int id){
				
		        this.personService.removePerson(id);
		        return "redirect:/persons";
		    }
		
}
